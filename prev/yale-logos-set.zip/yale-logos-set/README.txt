﻿################################################################################
########## README LOGOS ##########
################################################################################

Included in this logo set:

• 8 image files in .png format at default and hi-resolution screen sizes, 
  in Yale blue and reversed white.

• Yale icon fonts with the Yale logos and shield, and sample usage HTML file.

• Multipart favicon.ico contains 5 resolutions in one file. Sample usage:

<link rel="shortcut icon" sizes="16x16 24x24 32x32 48x48 64x64" href="/images/favicon.ico" type="image/vnd.microsoft.icon">


NOTE: These logos are intended for use on web pages and web applications only, 
they are not designed for print or other uses. For all other uses please contact:

Office of the University Printer
PO Box 208227
New Haven, CT 06520-8227

street address:

2 Whitney Avenue, Suite 203
New Haven, CT 06510

203.432.9217 (T)
203.432.9247 (F)

